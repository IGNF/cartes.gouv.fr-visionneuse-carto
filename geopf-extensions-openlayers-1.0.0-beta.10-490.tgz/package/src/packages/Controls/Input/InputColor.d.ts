export default InputColor;
export type InputColorConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Les couluers à mettre en options (valeur: libellé)
     */
    options: {
        [x: string]: string;
    };
};
/**
 * @classdesc Input permettant de sélectionner des icônes. Celle-ci sont extraites de remixicon.
 */
declare class InputColor extends CustomSelectGrid {
    /**
     * Constructeur du contrôle InputColor
     * @param {InputColorConfig} options Options du contrôle
     */
    constructor(options?: InputColorConfig);
    /**
     * @param {InputColorConfig} options Options du contrôle
     * @override
     */
    override _initialize(options: InputColorConfig): void;
    /**
     * @param {InputColorConfig} options Options du contrôle
     * @override
     */
    override _initContainer(options: InputColorConfig): void;
    /**
     * Met une couleur dans l'input.
     *
     * Peut notamment être utilisé pour mettre une valeur initiale.
     * @param {String} color Couleur à mettre dans l'input
     * @param {String} [label] Libellé de la couleur
     */
    setColor(color: string, label?: string): void;
    selectOption(index: any, silent?: boolean): void;
}
import CustomSelectGrid from "./CustomSelectGrid.js";
//# sourceMappingURL=InputColor.d.ts.map