export default CustomSelectGrid;
export type CustomSelectConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Type de l'input
     */
    type?: string | undefined;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Les options de la sélection (valeur: libellé)
     */
    options: {
        [x: string]: string;
    };
};
/**
 * @typedef {Object} CustomSelectConfig
 * @property {string} label Le label de l'input
 * @property {string} [labelInfo] Info supplémentaire du label (ex: unité)
 * @property {string} property La propriété flat style correspondante
 * @property {string} [type] Type de l'input
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 * @property {Object<string, string>} options Les options de la sélection (valeur: libellé)
 */
/**
 * @see {@link https://www.w3.org/WAI/ARIA/apg/patterns/combobox/examples/combobox-select-only/} Pour voir l'inspiration
 */
declare class CustomSelectGrid extends CustomSelect {
    /**
     * Définit le nombre de colonne dans la grille (utilisé pour màj l'index)
     * @type {Number}
     */
    columnNb: number | undefined;
}
import CustomSelect from "./CustomSelect.js";
//# sourceMappingURL=CustomSelectGrid.d.ts.map