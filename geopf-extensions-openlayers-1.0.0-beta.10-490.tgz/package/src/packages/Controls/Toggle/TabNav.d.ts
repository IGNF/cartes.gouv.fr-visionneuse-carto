export default TabNav;
/**
 * @classdesc
 * Classe gérant une navigation tertiaire avec onglets.
 *
 * @alias TabNav
 * @module TabNav
 * @extends {Control}
 */
declare class TabNav extends Control {
    /**
     * Constructeur du TabNav.
     * @constructor
     * @param {TabNavOptions} options Options du constructeur
     */
    constructor(options?: TabNavOptions);
    navigationList: Element | null;
    /**
     * @param {TabNavOptions} options Options de construction
     */
    _initialize(options: TabNavOptions): void;
    tabNavClass: string | undefined;
    _uid: any;
    items: Collection<any> | undefined;
    selectors: {
        NAVIGATION: string;
        NAVIGATION_LIST: string;
        NAVIGATION_ITEM: string;
        NAVIGATION_LINK: string;
        CURRENT_LINK: string;
        OPEN_TAB: string;
        CLOSE_TAB: string;
    } | undefined;
    contentContainer: HTMLElement | undefined;
    setMap(map: any): void;
    /**
     * Crée le conteneur principal de la navigation.
     * @protected
     * @param {TabNavOptions} options Options de construction
     * @returns {HTMLElement} Élément div de navigation
     */
    protected _initContainer(options: TabNavOptions): HTMLElement;
    /**
     * @param {TabNavOptions} options Options du constructeur
     */
    _initEvents(options: TabNavOptions): void;
    /**
     * Ajoute plusieurs items à la navigation.
     * @param {Array<TabNavItemOptions>} items Liste des items à ajouter
     */
    addItems(items: Array<TabNavItemOptions>): void;
    /**
     * Ajoute un item à la navigation.
     * @param {TabNavItem|TabNavItemOptions} options Item à ajouter
     */
    addItem(options: TabNavItem | TabNavItemOptions): void;
    /**
     * Booléen retournant le nombre d'item dans la navigation
     * @returns {Boolean} Vrai si contient des éléments
     */
    hasNavItem(): boolean;
    /**
     * Retourne le lien actuellement sélectionné.
     * @returns {TabNavItem|null} Bouton actuellement sélectionné
     */
    getCurrentLink(): TabNavItem | null;
    /**
     * Définit le lien courant et gère l'affichage du contenu.
     * @param {TabNavItem} link Bouton à activer
     */
    setCurrentLink(link: TabNavItem): void;
    currentItem: TabNavItem | undefined;
    /**
     * Vérifie si la navigation contient des items.
     * @returns {Boolean} True si au moins un item existe
     */
    hasItems(): boolean;
    /**
     * Retourne l'élément principal de la navigation.
     * @returns {HTMLElement} Élément div de navigation
     */
    getElement(): HTMLElement;
    /**
     * Affiche la navigation.
     */
    show(): void;
    /**
     * Masque la navigation.
     */
    hide(): void;
    /**
     * Affiche un item.
     * @param {TabNavItem} item Item à afficher
     */
    showItem(item: TabNavItem): void;
    /**
     * Masque un item.
     * @param {TabNavItem} item Item à masquer
     */
    hideItem(item: TabNavItem): void;
    /**
     * Sélectionne le premier onglet.
     */
    selectFirst(): void;
    /**
     * Supprime tous les items de la navigation.
     */
    clear(): void;
}
import Control from "../Control";
import Collection from "ol/Collection";
import TabNavItem from "./TabNavItem";
//# sourceMappingURL=TabNav.d.ts.map