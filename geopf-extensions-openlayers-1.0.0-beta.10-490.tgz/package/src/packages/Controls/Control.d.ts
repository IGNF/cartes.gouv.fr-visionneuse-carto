export default ControlExtended;
declare class ControlExtended extends Control {
    constructor(options: any);
    listable: boolean;
    description: any;
    setPosition(pos: any): void;
    updatePosition(pos: any): void;
    /**
     * Ajoute un écouteur d'événement sur la taille de la carte
     *
     * @param {Map} map Carte
     * @override
     */
    override setMap(map: Map): void;
    /**
     * Initialise les valeurs du contrôle.
     * @protected
     * @param {Object} options Options du constructeur (dépend du contrôle)
     * @abstract
     */
    protected _initialize(options: any): void;
    /**
     * Initialise le DOM du contrôle.
     * @protected
     * @param {Object} options Options du constructeur (dépend du contrôle)
     * @abstract
     */
    protected _initContainer(options: any): void;
    /**
     * Initialise les événements sur le contrôle.
     * @protected
     * @param {Object} options Options du constructeur (dépend du contrôle)
     * @abstract
     */
    protected _initEvents(options: any): void;
}
import Control from "ol/control/Control";
import { Map } from "ol";
//# sourceMappingURL=Control.d.ts.map