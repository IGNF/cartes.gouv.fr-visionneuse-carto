export default SearchEngineGeocodeIGN;
/**
 * Options pour l'autocomplétion.
 */
export type AutocompleteOptions = {
    /**
     * - Options passées à Gp.Services.autoComplete
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses retournées
     */
    maximumResponses?: number | undefined;
    /**
     * - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
     */
    triggerGeocode?: boolean | undefined;
    /**
     * - Délai (ms) avant déclenchement du géocodage automatique
     */
    triggerDelay?: number | undefined;
    /**
     * - Si vrai, embellit/filtre les résultats
     */
    prettifyResults?: boolean | undefined;
};
/**
 * Options pour la recherche finale (géocodage).
 */
export type SearchOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Nombre maximal de réponses.
     */
    maximumResponses?: number | undefined;
    /**
     * - Active le filtrage des résultats par couche.
     */
    filterLayers?: boolean | undefined;
    /**
     * - Indexs utilisés (ex. "address,poi").
     */
    index?: string | string[] | undefined;
    /**
     * - Limite de résultats.
     */
    limit?: number | undefined;
};
/**
 * Options pour le géocodage manuel.
 */
export type GeocodeOptions = {
    /**
     * - Options passées à Gp.Services.geocode.
     */
    serviceOptions?: any;
    /**
     * - Texte à géocoder.
     */
    location?: string | undefined;
    /**
     * - Callback en cas de succès.
     */
    onSuccess?: Function | undefined;
    /**
     * - Callback en cas d'échec.
     */
    onFailure?: Function | undefined;
};
/**
 * Options de construction d'un service de recherche.
 */
export type AbstractSearchServiceOptions = {
    /**
     * - Clé API pour les services IGN.
     */
    apiKey?: string | undefined;
    /**
     * - Forcer HTTPS.
     */
    ssl?: boolean | undefined;
    /**
     * - Options de l'autocomplétion.
     */
    autocompleteOptions?: AutocompleteOptions | undefined;
    /**
     * - Options de la recherche finale.
     */
    searchOptions?: SearchOptions | undefined;
    /**
     * - Options de géocodage.
     */
    geocodeOptions?: GeocodeOptions | undefined;
    autocomplete?: boolean | undefined;
    index?: string | undefined;
    limit?: number | undefined;
    returnTrueGeometry?: boolean | undefined;
};
/**
 * Options pour le contrôle SearchEngineBase.
 */
export type SearchEngineBaseOptions = {
    /**
     * - Élément DOM ou sélecteur cible.
     */
    target?: string | HTMLElement | undefined;
    /**
     * - Texte du titre du bouton.
     */
    title?: string | undefined;
    /**
     * - Label affiché.
     */
    label?: string | undefined;
    /**
     * - Texte d'aide.
     */
    hint?: string | undefined;
    /**
     * - Comportement en tant que barre de recherche.
     */
    search?: boolean | undefined;
    /**
     * - Si vrai, le contrôle est repliable.
     */
    collapsible?: string | undefined;
    /**
     * - Libellé ARIA.
     */
    ariaLabel?: string | undefined;
    /**
     * - Placeholder de l'input.
     */
    placeholder?: string | undefined;
    /**
     * - Nombre minimal de caractères pour autocomplétion.
     */
    minChars?: number | undefined;
    /**
     * - Nombre maximal d'entrées affichées.
     */
    maximumEntries?: number | undefined;
    /**
     * - Gestion historique local (false|true|string).
     */
    historic?: string | boolean | undefined;
    /**
     * - Service de recherche.
     */
    searchService?: AbstractSearchService | undefined;
};
/**
 * Options pour le contrôle SearchEngineGeocodeIGN.
 * Étend SearchEngineBaseOptions et ajoute les options spécifiques du service IGN.
 */
export type SearchEngineGeocodeIGNOptions = SearchEngineBaseOptions & {
    serviceOptions?: AbstractSearchServiceOptions;
};
/**
 * @file
 * Contrôle de recherche spécialisé pour le géocodage IGN.
 * Ce contrôle hérite de SearchEngineBase et ajoute la gestion des options spécifiques IGN via la propriété `serviceOptions`.
 * Utilisez le typedef {@link SearchEngineGeocodeIGNOptions} pour bénéficier de l'autocomplétion et de la documentation dans VSCode/TypeDoc.
 *
 * @see {@link SearchEngineBaseOptions}
 * @see {@link AbstractSearchServiceOptions}
 */
/**
 * Options pour l'autocomplétion.
 * @typedef {Object} AutocompleteOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.autoComplete
 * @property {Number} [maximumResponses] - Nombre maximal de réponses retournées
 * @property {Boolean} [triggerGeocode=false] - Si vrai, déclenche une requête de géocodage lorsque l'autocomplétion échoue
 * @property {Number} [triggerDelay=1000] - Délai (ms) avant déclenchement du géocodage automatique
 * @property {Boolean} [prettifyResults=false] - Si vrai, embellit/filtre les résultats
 */
/**
 * Options pour la recherche finale (géocodage).
 * @typedef {Object} SearchOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {Number} [maximumResponses] - Nombre maximal de réponses.
 * @property {Boolean} [filterLayers] - Active le filtrage des résultats par couche.
 * @property {String|Array<String>} [index] - Indexs utilisés (ex. "address,poi").
 * @property {Number} [limit] - Limite de résultats.
 */
/**
 * Options pour le géocodage manuel.
 * @typedef {Object} GeocodeOptions
 * @property {Object} [serviceOptions] - Options passées à Gp.Services.geocode.
 * @property {String} [location] - Texte à géocoder.
 * @property {Function} [onSuccess] - Callback en cas de succès.
 * @property {Function} [onFailure] - Callback en cas d'échec.
 */
/**
 * Options de construction d'un service de recherche.
 * @typedef {Object} AbstractSearchServiceOptions
 * @property {String} [apiKey] - Clé API pour les services IGN.
 * @property {Boolean} [ssl=true] - Forcer HTTPS.
 * @property {AutocompleteOptions} [autocompleteOptions] - Options de l'autocomplétion.
 * @property {SearchOptions} [searchOptions] - Options de la recherche finale.
 * @property {GeocodeOptions} [geocodeOptions] - Options de géocodage.
 * @property {Boolean} [autocomplete=true]
 * @property {String} [index="address,poi"]
 * @property {Number} [limit=1]
 * @property {Boolean} [returnTrueGeometry=false]
 */
/**
 * Options pour le contrôle SearchEngineBase.
 * @typedef {Object} SearchEngineBaseOptions
 * @property {HTMLElement|String} [target] - Élément DOM ou sélecteur cible.
 * @property {String} [title="Rechercher"] - Texte du titre du bouton.
 * @property {String} [label=""] - Label affiché.
 * @property {String} [hint=""] - Texte d'aide.
 * @property {Boolean} [search=false] - Comportement en tant que barre de recherche.
 * @property {String} [collapsible=false] - Si vrai, le contrôle est repliable.
 * @property {String} [ariaLabel="Rechercher"] - Libellé ARIA.
 * @property {String} [placeholder=""] - Placeholder de l'input.
 * @property {Number} [minChars=0] - Nombre minimal de caractères pour autocomplétion.
 * @property {Number} [maximumEntries=5] - Nombre maximal d'entrées affichées.
 * @property {Boolean|String} [historic=true] - Gestion historique local (false|true|string).
 * @property {AbstractSearchService} [searchService] - Service de recherche.
 */
/**
 * Options pour le contrôle SearchEngineGeocodeIGN.
 * Étend SearchEngineBaseOptions et ajoute les options spécifiques du service IGN.
 * @typedef {SearchEngineBaseOptions & {
 *   serviceOptions?: AbstractSearchServiceOptions
 * }} SearchEngineGeocodeIGNOptions
 */
/**
 * @classdesc
 * Moteur de recherche spécialisé pour le géocodage IGN (implémentation de SearchEngineBase).
 *
 * @alias ol.control.SearchEngineGeocodeIGN
 * @module SearchEngine
 * @extends SearchEngineBase
 */
declare class SearchEngineGeocodeIGN extends SearchEngineBase {
    /**
     * Constructeur du contrôle SearchEngineGeocodeIGN.
     *
     * @constructor
     * @param {SearchEngineGeocodeIGNOptions} [options] Options du contrôle.
     * @example
     * const ctrl = new SearchEngineGeocodeIGN({
     *   placeholder: "Rechercher...",
     *   serviceOptions: { apiKey: "votre-cle", returnTrueGeometry: true }
     * });
     */
    constructor(options?: SearchEngineGeocodeIGNOptions);
    /**
     * Initialise les options du contrôle.
     *
     * @override
     * @param {SearchEngineGeocodeIGNOptions} options - Options du constructeur.
     */
    override initialize(options: SearchEngineGeocodeIGNOptions): void;
    REMOVE_FEATURE_EVENT: string | undefined;
    /**
     * Initialise les événements du contrôle.
     *
     * @override
     * @param {SearchEngineGeocodeIGNOptions} options - Options du constructeur.
     */
    override _initEvents(options: SearchEngineGeocodeIGNOptions): void;
}
import AbstractSearchService from "../../Services/AbstractSearchService";
import SearchEngineBase from "./SearchEngineBase";
//# sourceMappingURL=SearchEngineGeocodeIGN.d.ts.map