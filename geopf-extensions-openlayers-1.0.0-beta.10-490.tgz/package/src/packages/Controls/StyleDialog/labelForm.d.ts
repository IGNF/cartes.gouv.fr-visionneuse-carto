export default labelForm;
/**
 * Formulaire de gestion de l'étiquette
 * @constant
 * @type {FlatStyleForm}
 */
declare const labelForm: FlatStyleForm;
import FlatStyleForm from "./FlatStyleForm.js";
//# sourceMappingURL=labelForm.d.ts.map