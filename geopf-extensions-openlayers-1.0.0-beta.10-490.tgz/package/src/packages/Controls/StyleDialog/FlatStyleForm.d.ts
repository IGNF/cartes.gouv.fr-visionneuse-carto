export default FlatStyleForm;
/**
 * Configuration pour un type input
 */
export type InputConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Le type de l'input.
     * Il faut passer par l'attribut `input` pour ajouter un input personnalisé.* En fonction du type, l'input sera soit un élément HTML de type `input` / `select`
     * , ou bien un enfant de {@link DefaultInput}.
     * Certaines valeurs de l'attributs changent le type d'input créé :
     * - `type : number` : Créé un élément de type {@link InputNumber};
     * - `type : color` : Créé un élément de type {@link InputColor};
     * - `type : default` : Créé un élément de type {@link DefaultInput};
     * - `type : pattern` : Créé un élément de type {@link CustomSelectGrid};
     * - `type : input` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input | input} de type `text`;
     * - `type : textarea` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea | textarea};
     * - `type : select` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select | select}.
     * Créé par défaut un élémént de type {@link CustomSelect}.
     */
    type: string | any;
    /**
     * Options de la sélection (valeur: libellé)
     */
    options: any;
    /**
     * Objet / classe permettant d'ajouter un input.
     * L'objet doit avoir une méthode `getInput()` et `getElement()` pour les inputs personnalisés.
     */
    input?: any;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Attributs supplémentaires à ajouter sur l'élément input / select.
     */
    attributes?: any;
    /**
     * `type : select` seulement. Texte du placeholder.
     */
    placeholder?: any;
    /**
     * `type:number` seulement. Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
};
/**
 * Configuration d'un formulaire de style.
 */
export type FlatStyleFormConfig = {
    /**
     * Indique si le formulaire a un bouton de validation.
     */
    hasbutton?: boolean | undefined;
};
/**
 * @typedef {Object} InputConfig Configuration pour un type input
 * @property {String} label Le label de l'input
 * @property {String} property La propriété flat style correspondante
 * @property {String|Object} type Le type de l'input.
 * Il faut passer par l'attribut `input` pour ajouter un input personnalisé.* En fonction du type, l'input sera soit un élément HTML de type `input` / `select`
 * , ou bien un enfant de {@link DefaultInput}.
 * Certaines valeurs de l'attributs changent le type d'input créé :
 * - `type : number` : Créé un élément de type {@link InputNumber};
 * - `type : color` : Créé un élément de type {@link InputColor};
 * - `type : default` : Créé un élément de type {@link DefaultInput};
 * - `type : pattern` : Créé un élément de type {@link CustomSelectGrid};
 * - `type : input` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input | input} de type `text`;
 * - `type : textarea` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea | textarea};
 * - `type : select` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select | select}.
 * Créé par défaut un élémént de type {@link CustomSelect}.
 * @property {Object<String, String>} options Options de la sélection (valeur: libellé)
 * @property {Object} [input] Objet / classe permettant d'ajouter un input.
 * L'objet doit avoir une méthode `getInput()` et `getElement()` pour les inputs personnalisés.
 * @property {Boolean} [disabled=false] Si vrai, désactive l'input
 * @property {Object} [attributes] Attributs supplémentaires à ajouter sur l'élément input / select.
 * @property {Object} [placeholder] `type : select` seulement. Texte du placeholder.
 * @property {string} [labelInfo] `type:number` seulement. Info supplémentaire du label (ex: unité)
 */
/**
 * @typedef {Object} FlatStyleFormConfig Configuration d'un formulaire de style.
 * @property {Boolean} [hasbutton] Indique si le formulaire a un bouton de validation.
 */
/**
 * @classdesc
 * Classe représentant un formulaire de style.
 * Un input peut être ajouté via la méthode `addInput(config)`.
 * Le paramètre `config.type` définit le type d'objet créé :
 *
 * - `type : number` : Créé un élément de type {@link InputNumber};
 * - `type : color` : Créé un élément de type {@link InputColor};
 * - `type : default` : Créé un élément de type {@link DefaultInput};
 * - `type : pattern` : Créé un élément de type {@link CustomSelectGrid};
 * - `type : input` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input | input} de type `text`;
 * - `type : textarea` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea | textarea};
 * - `type : select` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select | select}.
 * Créé par défaut un élémént de type {@link CustomSelect}.
 *
 * @extends ControlExtended
 */
declare class FlatStyleForm extends ControlExtended {
    /**
     * Constructeur du contrôle FlatStyleForm
     * @param {FlatStyleFormConfig} options - Options du contrôle
     */
    constructor(options?: FlatStyleFormConfig);
    _uid: any;
    /**
     * Collection des inputs indexés par leur propriété
     * @type {Object<String, DefaultInput|HTMLInputElement>}
     */
    inputs: any;
    container: HTMLDivElement;
    element: HTMLDivElement;
    submitButton: HTMLButtonElement | undefined;
    flatStyle: import("ol/style/flat.js").DefaultStyle;
    /**
     * Gestionnaire de soumission du formulaire.
     * Récupère les valeurs de tous les inputs et leurs propriétés associées.
     * @returns {Object} Valeur des inputs avec leurs propriétés associées
     * @protected
     */
    protected onSubmit(): any;
    /**
     * Initialise les valeurs des inputs à partir d'un style flat
     * @param {Object} flatStyle - Le style flat utilisé pour initialiser les inputs
     * @public
     */
    public setFlatStyle(flatStyle: any): void;
    /**
     * Ajoute un input au formulaire de style.
     * En fonction du paramètre `type`, l'élément créé sera différent.
     *
     * @see {@link InputConfig} pour plus d'informations sur le paramètre de construction.
     *
     * @param {InputConfig} config Config pour la construction de l'input.
     * @returns {HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement|DefaultInput} Input créé. Cela n'est pas nécessairement l'élément `input`, mais peut être l'objet créé.
     */
    addInput(config: InputConfig): HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | DefaultInput;
    /**
     * Ajoute un input simple au formulaire.
     * Si `config.type` est un objet, utilise les méthodes `getInput` et `getElement` de cet objet pour
     *
     * @param {InputConfig} config Config pour la construction de l'input.
     * @returns {HTMLInputElement} Input créé.
     * @private
     */
    private _addInputElement;
    /**
     * Ajoute une séparation visuelle (break) au formulaire.
     * Retourne l'élément pour le réutiliser au besoin.
     * @param {String} property - La propriété correspondante
     * @returns {Element} Élément break
     * @public
     */
    public addBreak(property: string): Element;
    /**
     * Récupère un input par sa propriété
     * @param {String} property - Le nom de la propriété
     * @returns {DefaultInput} La configuration de l'input ou undefined si non trouvé
     */
    getInput(property: string): DefaultInput;
    /**
     * Récupère le contenu global du formulaire
     * @returns {HTMLElement} L'élément conteneur du formulaire (avec la grille et le bouton)
     */
    getContent(): HTMLElement;
}
import ControlExtended from "../Control.js";
import DefaultInput from "../Input/DefaultInput.js";
//# sourceMappingURL=FlatStyleForm.d.ts.map