/**
 * @classdesc
 * Les événements envoyés par des instances de {@link FlatStyleForm}
 * sont des instances de ce type ou de {@link SubmitEvent} (seulement si bouton de validation présent dans le formulaire).
 */
export class StyleEvent extends BaseEvent {
    /**
     * @param {String} property Propriété flat style.
     * @param {any} value Valeur correspondante.
     */
    constructor(property: string, value: any);
    /**
     * Propriété flatstyle.
     * @type {String}
     * @api
     */
    property: string;
    /**
     * Valeur correspondante à la propriété flat style.
     * @type {any}
     * @api
     */
    value: any;
}
/**
 * @classdesc
 * Le clic sur le bouton de validation du formulaire de {@link FlatStyleForm} sont des instances de ce type (sinon, voir {@link StyleEvent}).
 */
export class SubmitEvent extends BaseEvent {
    /**
     * @param {Object} flatStyle Objet flat style au complet.
     */
    constructor(flatStyle: any);
    /**
     * Objet flat style correspondant au formulaire.
     * @type {Object}
     * @api
     */
    flatStyle: any;
}
export default FlatStyleForm;
/**
 * Configuration pour un type input
 */
export type InputConfig = {
    /**
     * Le label de l'input
     */
    label: string;
    /**
     * La propriété flat style correspondante
     */
    property: string;
    /**
     * Le type de l'input.
     * Il faut passer par l'attribut `input` pour ajouter un input personnalisé.
     * En fonction du type, l'input sera soit un élément HTML de type `input` / `select`
     * , ou bien un enfant de {@link DefaultInput}.
     * Certaines valeurs de l'attributs changent le type d'input créé :
     * - `type : number` : Créé un élément de type {@link InputNumber};
     * - `type : color` : Créé un élément de type {@link InputColor};
     * - `type : default` : Créé un élément de type {@link DefaultInput};
     * - `type : pattern` : Créé un élément de type {@link CustomSelectGrid};
     * - `type : input` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input | input} de type `text`;
     * - `type : textarea` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea | textarea};
     * - `type : select` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select | select}.
     * Créé par défaut un élémént de type {@link CustomSelect}.
     */
    type: string | any;
    /**
     * Options de la sélection (valeur: libellé)
     */
    options: any;
    /**
     * Objet / classe permettant d'ajouter un input.
     * L'objet doit avoir une méthode `getInput()` et `getElement()` pour les inputs personnalisés.
     */
    input?: any;
    /**
     * Si vrai, désactive l'input
     */
    disabled?: boolean | undefined;
    /**
     * Attributs supplémentaires à ajouter sur l'élément input / select.
     */
    attributes?: any;
    /**
     * `type : select` seulement. Texte du placeholder.
     */
    placeholder?: any;
    /**
     * `type:number` seulement. Info supplémentaire du label (ex: unité)
     */
    labelInfo?: string | undefined;
};
/**
 * Configuration d'un formulaire de style.
 */
export type FlatStyleFormConfig = {
    /**
     * Indique si le formulaire a un bouton de validation.
     */
    hasbutton?: boolean | undefined;
};
/**
 * Type de géométrie parmi : `'Point'`, `'LineString'`, `'LinearRing'`,
 * `'Polygon'`, `'MultiPoint'`, `'MultiLineString'`, `'MultiPolygon'`,
 * `'GeometryCollection'`, ou `'Circle'`.
 */
export type GeomType = "Point" | "LineString" | "LinearRing" | "Polygon" | "MultiPoint" | "MultiLineString" | "MultiPolygon" | "GeometryCollection" | "Circle";
export type FlatStyleFormOnSignature<Return> = import("ol/Observable.js").OnSignature<import("ol/Observable.js").EventTypes, import("ol/events/Event.js").default, Return> & import("ol/Observable").OnSignature<import("ol/ObjectEventType.js").Types, import("ol/Object").ObjectEvent, Return> & import("ol/Observable.js").OnSignature<"style", StyleEvent, Return> & import("ol/Observable.js").OnSignature<"submit", SubmitEvent, Return> & import("ol/Observable").CombinedOnSignature<import("ol/Observable").EventTypes | import("ol/ObjectEventType.js").Types | "style" | "submit", Return>;
import BaseEvent from "ol/events/Event.js";
/**
 * @template Return
 * @typedef {import("ol/Observable.js").OnSignature<import("ol/Observable.js").EventTypes, import("ol/events/Event.js").default, Return> &
 *   import("ol/Observable").OnSignature<import("ol/ObjectEventType.js").Types, import("ol/Object").ObjectEvent, Return> &
 *   import("ol/Observable.js").OnSignature<'style', StyleEvent, Return> &
 *   import("ol/Observable.js").OnSignature<'submit', SubmitEvent, Return> &
 *   import("ol/Observable").CombinedOnSignature<import("ol/Observable").EventTypes|import("ol/ObjectEventType.js").Types|'style'|'submit', Return>} FlatStyleFormOnSignature
 */
/**
 * @classdesc
 * Classe représentant un formulaire de style.
 * Un input peut être ajouté via la méthode `addInput(config)`.
 * Le paramètre `config.type` définit le type d'objet créé :
 *
 * - `type : number` : Créé un élément de type {@link InputNumber};
 * - `type : color` : Créé un élément de type {@link InputColor};
 * - `type : default` : Créé un élément de type {@link DefaultInput};
 * - `type : pattern` : Créé un élément de type {@link CustomSelectGrid};
 * - `type : input` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input | input} de type `text`;
 * - `type : textarea` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/textarea | textarea};
 * - `type : select` : Créé un élément HTML {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/select | select}.
 * Créé par défaut un élémént de type {@link CustomSelect}.
 *
 * @extends ControlExtended
 * @fires FlatStyleFormEventType#style
 * @fires FlatStyleFormEventType#submit
 */
declare class FlatStyleForm extends ControlExtended {
    /**
     * Constructeur du contrôle FlatStyleForm
     * @param {FlatStyleFormConfig} options - Options du contrôle
     */
    constructor(options?: FlatStyleFormConfig);
    _uid: any;
    /** @type {FlatStyleFormOnSignature<import("ol/events").EventsKey>} */
    on: FlatStyleFormOnSignature<import("ol/events").EventsKey>;
    /** @type {FlatStyleFormOnSignature<import("ol/events").EventsKey>} */
    once: FlatStyleFormOnSignature<import("ol/events").EventsKey>;
    /** @type {FlatStyleFormOnSignature<void>} */
    un: FlatStyleFormOnSignature<void>;
    /**
     * Collection des inputs indexés par leur propriété
     * @type {Object<String, DefaultInput|HTMLInputElement>}
     */
    inputs: any;
    container: HTMLDivElement;
    element: HTMLDivElement;
    submitButton: HTMLButtonElement | undefined;
    flatStyle: import("ol/style/flat.js").DefaultStyle;
    /**
     * Gestionnaire de soumission du formulaire.
     * Récupère les valeurs de tous les inputs et leurs propriétés associées.
     * @returns {Object} Valeur des inputs avec leurs propriétés associées
     * @protected
     */
    protected onSubmit(): any;
    /**
     * Initialise les valeurs des inputs à partir d'un style flat
     * @param {Object} flatStyle - Le style flat utilisé pour initialiser les inputs
     * @public
     */
    public setFlatStyle(flatStyle: any): void;
    /**
     * Ajoute un input au formulaire de style.
     * En fonction du paramètre `type`, l'élément créé sera différent.
     *
     * @see {@link InputConfig} pour plus d'informations sur le paramètre de construction.
     *
     * @param {InputConfig} config Config pour la construction de l'input.
     * @returns {HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement|DefaultInput} Input créé. Cela n'est pas nécessairement l'élément `input`, mais peut être l'objet créé.
     */
    addInput(config: InputConfig): HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | DefaultInput;
    /**
     * Ajoute un input simple au formulaire.
     * Si `config.type` est un objet, utilise les méthodes `getInput` et `getElement` de cet objet pour
     *
     * @param {InputConfig} config Config pour la construction de l'input.
     * @returns {HTMLInputElement} Input créé.
     * @private
     */
    private _addInputElement;
    /**
     * Ajoute une séparation visuelle (break) au formulaire.
     * Retourne l'élément pour le réutiliser au besoin.
     * @param {String} property - La propriété correspondante
     * @returns {Element} Élément break
     * @public
     */
    public addBreak(property: string): Element;
    /**
     * Modifie le type de géométrie dans l'attribut `data-geom` du conteneur du formulaire.
     * L'appel à cette méthode enlève toute autre géométrie qui aurait été affichée.
     *
     * Il est possible de passer une feature ou un array de feature
     * (les types de géométries sont alors récupérés depuis la méthode
     * `feature.getGeometry().getType()`) ou bien une chaîne de
     * charactère correspondant à un type de géométrie valide
     * (voir {@link GeomType GeomType})
     *
     * Les éléments affichés dépendent de la propriété flat-style correspondante :
     * - Type `'Point'` ou `'MultiPoint'` : propriété commençant par `'point'` ou `'circle'`;
     * - Type `'LineString'` ou `'MultiLineString'` : propriété commençant par `'line'` ou `'stroke'`;
     * - Type `'Polygon'` ou `'MultiPolygon'` : propriété commençant par `'fill'` ou `'stroke'`;
     *
     * @param {Feature|Array<Feature>|GeomType} featureOrGeomName Feature ou type de géométrie
     */
    setGeom(featureOrGeomName: Feature | Array<Feature> | GeomType): void;
    /**
     * Retourne les types de géométries affichés dans le formulaire.
     * @returns {String} Valeur contenu dans le data-geom de l'élément principal
     */
    getGeom(): string;
    /**
     * Récupère un input par sa propriété
     * @param {String} property - Le nom de la propriété
     * @returns {DefaultInput} La configuration de l'input ou undefined si non trouvé
     */
    getInput(property: string): DefaultInput;
    /**
     * Récupère le contenu global du formulaire
     * @returns {HTMLElement} L'élément conteneur du formulaire (avec la grille et le bouton)
     */
    getContent(): HTMLElement;
    /**
     * Récupère le contenu global du formulaire
     * @returns {HTMLElement} L'élément conteneur du formulaire (avec la grille et le bouton)
     */
    getElement(): HTMLElement;
}
import ControlExtended from "../Control.js";
import DefaultInput from "../Input/DefaultInput.js";
import Feature from "ol/Feature.js";
//# sourceMappingURL=FlatStyleForm.d.ts.map