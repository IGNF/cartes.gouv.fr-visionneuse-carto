export default ModifyingInteraction;
/** Modifying interaction
 * @events delete, cut, copy, paste
 */
declare class ModifyingInteraction extends Modify {
    /**
     * Initialize modifying interaction
     * @param {*} options extend Openlayers modifying options
     * @param {ol.interaction.Select} [options.select] - Selecting interaction linked to modifying interaction
     * @param {Function} [options.modifyCondition] - Function to determine if modifying interaction should be activated
     * @param {Number} [options.hitTolerance] - hitTolerance of point vertices (default 3)
     */
    constructor(options: any);
    _menu: Menu;
    _select: any;
    longtouch: LongTouch;
    _islongtouch: boolean;
    _modifyCondition: any;
    _onKey: (evt: any) => void;
    /** Chek if a feature is selected at pixel
     * @param {ol.Pixel} pixel Pixel to check
     * @return {Array<Feature>|Boolean} Found feature or false
     */
    selectedAtPixel(pixel: ol.Pixel): Array<Feature> | boolean;
    /**
     * Overwrite OpenLayers setMap method
     *
     * @param {Map} map - Map.
     */
    setMap(map: Map<any, any>): void;
    /** Delete selected features */
    deleteSelection(): void;
    /** Overwrite OpenLayers Handle event on the map
     * @param {ol.MapBrowserEvent} e Event
     * @returns {Boolean} Whether to propagate the event further
     */
    handleEvent(e: ol.MapBrowserEvent): boolean;
    _showContextMenu(e: any, isPoint: any): void;
    _isOnPoint(e: any): any;
}
import Modify from "ol/interaction/Modify";
import Menu from "../Controls/ContextMenu/SimpleMenu";
import LongTouch from "./LongTouch.js";
//# sourceMappingURL=Modifying.d.ts.map