export default Draw;
/**
 * @classdesc
 * Contrôle de dessin.
 *
 * @alias ol.control.Draw
 * @module Draw
 */
declare class Draw extends ToggleContent {
    /**
     * Tableau des toggle interactions contenant les interactions de dessin
     * @type {Collection<ToggleInteraction>}
     */
    toggleInteractions: Collection<ToggleInteraction> | undefined;
    /**
     * Interaction de sélection
     * @type {Select}
     */
    select: Select | undefined;
    /**
     * Renvoie l'intéraction de sélection lié au contrôle
     * @returns {Select} Intéraction de sélection
     */
    getSelect(): Select;
    /**
     * @param {DrawOptions} options Options du contrôle
     * @override
     */
    override _initEvents(options: DrawOptions): void;
    /**
     * Récupère l'intéraction active si elle existe
     * @returns {ToggleInteraction|undefined} Interaction active (s'il y'en a une)
     */
    getActiveToggle(): ToggleInteraction | undefined;
    /**
     * @param {DrawOptions} options Options du constructeur
     * @override
     */
    override _initContainer(options: DrawOptions): void;
    btnGroup: HTMLDivElement | undefined;
    /**
     * @param {Map} map Carte à ajouter
     * @override
     */
    override setMap(map: Map): void;
    /**
     * Ajoute une interaction au contrôle
     * @param {InteractionOptions} options Options pour l'ajout de l'intéraction
     */
    addInteraction(options: InteractionOptions): void;
}
import ToggleContent from "../Toggle/ToggleContent";
import ToggleInteraction from "../Toggle/ToggleInteraction";
import Collection from "ol/Collection.js";
import { Select } from "ol/interaction";
import { Map } from "ol";
//# sourceMappingURL=Draw.d.ts.map