export default SelectingInteraction;
/** Outil de selection et d'interaction avec des features
 * Gestion du double click sur un objet selectione
 * Gestion propre du clear sur une selection (nettoyage de la liste des features et dispatch d'un evenement select)
 * Gestion du style de selection par defaut
 * Dispatch dblclick when double clicking on a selected feature
 * @extends {ol.interaction.Select}
 */
declare class SelectingInteraction {
    /** Outil de selection avec gestion du doule click / modify interaction
     * @param {Object} options extend ol/interaction/Select options
     * @param {Function} [options.showPoint] - Function to determine if should diplay points on line style  (default false)
     */
    constructor(options: {
        showPoint?: Function | undefined;
    });
    _showPoints: any;
    /** Show points on selected features (lines and polygons)
     * @param {Function} fn Function to determine if should diplay points on line style
     */
    showPoints(fn: Function): void;
    /** Chek if a feature is selected at pixel
     * @param {ol.Pixel} pixel Pixel to check
     * @return {Array<Feature>|Boolean} Found features or false
     */
    selectedAtPixel(pixel: ol.Pixel): Array<Feature> | boolean;
    /** Clear interaction properly and remove
     * Dispatch deselect event
     */
    clear(): void;
}
//# sourceMappingURL=Selecting.d.ts.map