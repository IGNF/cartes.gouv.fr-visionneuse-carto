export const defaultFlatStyle: {};
export function selectStyle(type: any, featureType: any, iconSrc: any): any;
import { getFlatCoordinates } from "./selectStyle";
export { getFlatCoordinates };
//# sourceMappingURL=selectFlatStyle.d.ts.map